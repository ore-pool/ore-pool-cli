./ore-miner  claim --address 8Hq1HrYeHN76aGsB6XujYW5xW27cinvZoCAsmFjcdzDk  --invcode 888888
pause

